function createPlayer() { 
   
    ctx.drawImage(player_img, player.x - player_img.width ,player.y - player_img.height);
    
}

function createMissile() {
   
    let x;
    let y;
    let direction =["UP","DOWN","LEFT","RIGHT"];

    let randomdDirection = direction[Math.floor((Math.random() * 4))];

    if(randomdDirection == "UP"){

        x = Math.random() * canvas.width;
        y = canvas.height;
        
    }else if(randomdDirection == "DOWN"){

        x = Math.random() * canvas.width;
        y = 0;

    }else if(randomdDirection == "LEFT"){

        x = canvas.width;
        y = Math.random() * canvas.height;

    }else if(randomdDirection == "RIGHT"){

        x = 0;
        y = Math.random() * canvas.height;

    }


    let missile = {x: x , y: y , direction: randomdDirection};
    missiles.push(missile);

}

function createScore(){
    
    score ++;
    ctx.fillStyle = 'green';
    ctx.font = '24px sans-serif';
    ctx.fillText('score : ' + score, 10, 30);


}

function createGameOver(){

    ctx.fillStyle = 'red';
    ctx.font = '32px fantasy' ;
    ctx.fillText('Game Over', canvas.width / 2 - 100, canvas.height / 2);

}


function updatePlayer() {
    if (keys['ArrowUp'] && player.y - player_img.height  > 0) player.y -= player.speed;
    if (keys['ArrowDown'] && player.y - player_img.height < canvas.height - player_img.height) player.y += player.speed;
    if (keys['ArrowLeft'] && player.x - player_img.width > 0) player.x -= player.speed;
    if (keys['ArrowRight'] && player.x + player_img.width < canvas.width + player_img.width) player.x += player.speed;
}

function updateMissiles() {
    for (let i = missiles.length - 1; i >= 0; i--) {
        let missile = missiles[i];

        if (missile.direction == "UP") {
            missile.y -= missileSpeed;
        }else  if (missile.direction == "DOWN") {
            missile.y += missileSpeed;
        }else  if (missile.direction == "LEFT") {
            missile.x -= missileSpeed;
        }else  if (missile.direction == "RIGHT") {
            missile.x += missileSpeed;
        }

        if (missile.x < 0 || missile.x > canvas.width || missile.y < 0 || missile.y > canvas.height) {
            missiles.splice(i, 1);
        }

        if (missile.x + missileSize / 2 > player.x - player_img.width / 2  &&
            missile.x - missileSize / 2 < player.x + player_img.width / 2  &&
            missile.y + missileSize / 2 > player.y - player_img.height / 2  &&
            missile.y - missileSize / 2 < player.y + player_img.height / 2 ) {
            gameOver = true;
        }
    }
}


let canvas = document.getElementById('frame');
let ctx = canvas.getContext('2d');

let player = {
    x: canvas.width / 2,
    y: canvas.height / 2, 
    speed: 5
};

let missiles = [];
let missileSize = 10;
let missileSpeed = 3;

let gameOver = false;

let score = 0;

let player_img = new Image();
player_img.src = "img/fighter_plane.png";


let keys = {};

window.addEventListener('keydown', (e) => {
    keys[e.key] = true;
});

window.addEventListener('keyup', (e) => {
    keys[e.key] = false;
});

function gameStart() {
    if (gameOver) {
        createGameOver();
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    updatePlayer();
    createPlayer(); 
    updateMissiles();
    missiles.forEach((missile) => {
        ctx.fillStyle = 'orange';
        ctx.beginPath();
        ctx.arc(missile.x, missile.y, missileSize / 2, 0, Math.PI * 2);
        ctx.fill();
    });

    createScore();

    requestAnimationFrame(gameStart);
}
setInterval(createMissile, 500);
gameStart();

